# Talking-to-Plants
“Talking to Plants” via Active Digital Image Processing: Industry 4.0, IoT, Technology for Future Farming

## Install:
`git clone https://github.com/ArturCr/Talking-to-Plants.git`

## Team Members:
| name  | user |
| ------------- | ------------- |
| Justin Tan | JUSTUN9 |
| David Mohammadi | davidmo13|
| Momin Anwar | mominanwar|
| Mujhtaba Afzal | Gunflower123 |
| Sam Ryder | SamRyder |
| Flavia Dumitrica | flaviamihaela |
| Marton gonczy | martongonczy |
| Artur Cruz | ArturCr |
