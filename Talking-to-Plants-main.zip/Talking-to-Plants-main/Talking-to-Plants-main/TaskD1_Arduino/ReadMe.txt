v0.2

GPS, time since startup, read, and write to SD capability
Files not overwrote, instead additional writes are added to the end

Commands,
t - Time data
g - GPS data
w %filename% %data% - Write to SD Card
r %filename% - Read from SD Card, if file exists
